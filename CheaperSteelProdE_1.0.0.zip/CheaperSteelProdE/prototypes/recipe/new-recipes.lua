data:extend(
{
  {
    type = "recipe",
    name = "steel-plate",
    category = "smelting",
    enabled = false,
    energy_required = 3.2,
    ingredients = {{type = "item", name = "iron-plate", amount = 1}},
    results = {{type="item", name="steel-plate", amount=1}},
    allow_productivity = true
  }
})
